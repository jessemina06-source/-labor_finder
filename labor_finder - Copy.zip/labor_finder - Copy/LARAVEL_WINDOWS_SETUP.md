# Laravel Windows Setup and SQLite Fix

This guide documents the actual fix for the problems we encountered while setting up Laravel on Windows.

## Problem summary

The Laravel app was failing with:

- `php` not recognized as an internal or external command
- `could not find driver` when using SQLite

These were caused by two separate issues:

1. The PHP installation directory was not on the Windows `PATH`.
2. The SQLite extensions were not enabled in the PHP configuration.

## Root cause

### 1) Missing PATH for PHP

The PHP binary was installed but not discoverable by Windows command prompt unless the full file path was used.

### 2) Missing SQLite driver

Laravel uses SQLite for session storage and database access. The PHP install was missing the SQLite driver modules:

- `pdo_sqlite`
- `sqlite3`

Without them, Laravel could not open the session database or the app database file.

## Fixes applied

### Enable PHP in PATH

Add the PHP install directory to the Windows user PATH.

Example:

```cmd
setx PATH "%PATH%;C:\Users\Russel Carillo\AppData\Local\Microsoft\WinGet\Packages\PHP.PHP.8.3_Microsoft.Winget.Source_8wekyb3d8bbwe"
```

Then open a new terminal before running Laravel commands again.

### Enable SQLite extensions in PHP

In the active PHP configuration file, uncomment the SQLite extension lines:

```ini
extension=pdo_sqlite
extension=sqlite3
```

If the file does not exist yet, copy the development configuration to the active config file before editing.

### Make sure the SQLite database file exists

Laravel expects the database file at:

```text
app\database\database.sqlite
```

Create it if it is missing.

## Required commands

Run these from the project folder:

```cmd
cd /d "C:\Users\Russel Carillo\OneDrive\Documents\labor_finder\app"
php artisan migrate --force
php artisan serve
```

## Verification

We verified the fix with fresh commands:

```cmd
php -m
```

This showed:

- `pdo_sqlite`
- `sqlite3`

Then:

```cmd
php artisan migrate --force
```

completed successfully.

## Useful reminders

- Always open a new terminal after changing `PATH`.
- Always run Laravel commands from the app folder, not the parent folder.
- If `php` is still not found, use the direct PHP path temporarily:

```cmd
"C:\Users\Russel Carillo\AppData\Local\Microsoft\WinGet\Packages\PHP.PHP.8.3_Microsoft.Winget.Source_8wekyb3d8bbwe\php.exe" artisan serve
```

## Final status

The environment is now working for Laravel on Windows with SQLite support enabled.
