<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-bold">Jobs</h1>
    <?php if(Auth::user()->role === 'employer'): ?>
        <a href="<?php echo e(route('job-posts.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Post New Job
        </a>
    <?php endif; ?>
</div>


<div class="border-b border-gray-200 mb-6">
    <nav class="flex space-x-6">
        <?php
            $tabs = [
                'open' => 'Available Jobs',
                'posted' => 'My Posted Jobs',
                'contracts' => 'My Contracts',
            ];
        ?>
        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('job-posts.index', ['filter' => $key])); ?>"
               class="pb-3 -mb-px border-b-2 text-sm font-medium <?php echo e($filter === $key ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                <?php echo e($label); ?>

                <span class="ml-1 text-xs <?php echo e($filter === $key ? 'text-blue-500' : 'text-gray-400'); ?>">(<?php echo e($counts[$key]); ?>)</span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
</div>

<div class="grid grid-cols-1 gap-6">
    <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white shadow rounded-lg p-6">
            <div class="flex justify-between items-start">
                <div>
                    <h2 class="text-xl font-bold text-blue-600">
                        <a href="<?php echo e(route('job-posts.show', $job)); ?>"><?php echo e($job->title); ?></a>
                    </h2>
                    <p class="text-sm text-gray-500">
                        Posted by <?php echo e($job->user->name); ?> • <?php echo e($job->created_at->diffForHumans()); ?>

                    </p>
                    <div class="mt-2 flex items-center gap-2">
                        <?php if($job->isAccepted()): ?>
                            <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                                Contracted
                            </span>
                            <span class="text-xs text-gray-600">by <?php echo e($job->acceptedBy->name); ?></span>
                        <?php elseif($job->isOpen()): ?>
                            <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                                Open
                            </span>
                        <?php else: ?>
                            <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-gray-200 text-gray-700">
                                Closed
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-right">
                    <span class="text-lg font-bold text-green-600">₱<?php echo e(number_format($job->rate, 2)); ?></span>
                    <p class="text-sm text-gray-500"><?php echo e($job->location); ?></p>
                </div>
            </div>

            <p class="mt-4 text-gray-700"><?php echo e(Str::limit($job->description, 150)); ?></p>

            <div class="mt-4 flex flex-wrap items-center gap-3">
                <a href="<?php echo e(route('job-posts.show', $job)); ?>" class="text-sm text-blue-600 hover:underline">View Details</a>

                
                <?php if($job->isAcceptableBy(Auth::user())): ?>
                    <form action="<?php echo e(route('job-posts.accept', $job)); ?>" method="POST"
                          onsubmit="return confirm('Accept this job? It will be added to your contracts.')">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white text-sm font-bold py-1 px-3 rounded">
                            Accept Job
                        </button>
                    </form>
                <?php endif; ?>

                
                <?php if($job->isAccepted() && ($job->isAcceptedBy(Auth::user()) || $job->isPostedBy(Auth::user()))): ?>
                    <form action="<?php echo e(route('job-posts.release', $job)); ?>" method="POST"
                          onsubmit="return confirm('Cancel this contract? The job will be open again.')">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-sm text-orange-600 hover:underline">Cancel Contract</button>
                    </form>
                <?php endif; ?>

                <?php if($job->isPostedBy(Auth::user())): ?>
                    <form action="<?php echo e(route('job-posts.toggle-status', $job)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-sm text-gray-600 hover:underline">
                            <?php echo e($job->isOpen() ? 'Close Job' : 'Reopen Job'); ?>

                        </button>
                    </form>
                    <a href="<?php echo e(route('job-posts.edit', $job)); ?>" class="text-sm text-yellow-600 hover:underline">Update</a>
                    <form action="<?php echo e(route('job-posts.destroy', $job)); ?>" method="POST"
                          onsubmit="return confirm('Delete this job post permanently?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-sm text-red-600 hover:underline">Delete</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-center text-gray-500 py-8">
            <?php if($filter === 'contracts'): ?>
                You haven't accepted any jobs yet.
            <?php elseif($filter === 'posted'): ?>
                You haven't posted any jobs yet.
            <?php else: ?>
                No open jobs right now.
            <?php endif; ?>
        </p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Russel Carillo\OneDrive\Documents\labor_finder - Copy\app\resources\views/jobs/index.blade.php ENDPATH**/ ?>