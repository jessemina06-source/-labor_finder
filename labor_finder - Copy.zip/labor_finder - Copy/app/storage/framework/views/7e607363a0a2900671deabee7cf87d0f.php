<?php $__env->startSection('content'); ?>
<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
    <h1 class="text-3xl font-bold mb-4">Welcome to your Dashboard, <?php echo e(Auth::user()->name); ?>!</h1>
    <p class="text-gray-600 mb-6">You are logged in as a <strong><?php echo e(ucfirst(Auth::user()->role)); ?></strong>.</p>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="border rounded-lg p-4 hover:shadow-md transition">
            <h2 class="text-xl font-semibold mb-2">View Jobs</h2>
            <p class="text-gray-500 mb-4">Browse available labor opportunities.</p>
            <a href="<?php echo e(route('job-posts.index')); ?>" class="text-blue-600 hover:underline">Go to Jobs &rarr;</a>
        </div>

        <?php if(Auth::user()->role === 'employer'): ?>
            <div class="border rounded-lg p-4 hover:shadow-md transition">
                <h2 class="text-xl font-semibold mb-2">Post a Job</h2>
                <p class="text-gray-500 mb-4">Find laborers for your tasks.</p>
                <a href="<?php echo e(route('job-posts.create')); ?>" class="text-blue-600 hover:underline">Create Post &rarr;</a>
            </div>

            <div class="border rounded-lg p-4 hover:shadow-md transition">
                <h2 class="text-xl font-semibold mb-2">My Posted Jobs</h2>
                <p class="text-gray-500 mb-4">Update or delete the jobs you posted.</p>
                <a href="<?php echo e(route('job-posts.index', ['filter' => 'posted'])); ?>" class="text-blue-600 hover:underline">Manage Jobs &rarr;</a>
            </div>
        <?php endif; ?>

        <div class="border rounded-lg p-4 hover:shadow-md transition">
            <h2 class="text-xl font-semibold mb-2">My Contracts</h2>
            <p class="text-gray-500 mb-4">Jobs you accepted, and contracts you can cancel.</p>
            <a href="<?php echo e(route('job-posts.index', ['filter' => 'contracts'])); ?>" class="text-blue-600 hover:underline">View Contracts &rarr;</a>
        </div>

        <div class="border rounded-lg p-4 hover:shadow-md transition">
            <h2 class="text-xl font-semibold mb-2">Account Settings</h2>
            <p class="text-gray-500 mb-4">Update your profile, email, password, and account type.</p>
            <a href="<?php echo e(route('settings.index')); ?>" class="text-blue-600 hover:underline">Open Settings &rarr;</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Russel Carillo\OneDrive\Documents\labor_finder - Copy\app\resources\views/dashboard.blade.php ENDPATH**/ ?>