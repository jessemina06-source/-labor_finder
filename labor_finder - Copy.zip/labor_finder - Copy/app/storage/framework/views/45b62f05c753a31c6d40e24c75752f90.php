<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-lg p-8">
    <div class="flex justify-between items-start mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900"><?php echo e($jobPost->title); ?></h1>
            <p class="text-lg text-gray-600 mt-2">
                Posted by <?php echo e($jobPost->user->name); ?> • <?php echo e($jobPost->created_at->format('M d, Y')); ?>

            </p>
            <div class="mt-3">
                <?php if($jobPost->isAccepted()): ?>
                    <span class="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-blue-100 text-blue-800">
                        Contracted
                    </span>
                    <span class="text-sm text-gray-600 ml-2">
                        accepted by <?php echo e($jobPost->acceptedBy->name); ?>

                        on <?php echo e($jobPost->accepted_at->format('M d, Y')); ?>

                    </span>
                <?php elseif($jobPost->isOpen()): ?>
                    <span class="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-green-100 text-green-800">
                        Open
                    </span>
                <?php else: ?>
                    <span class="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-gray-200 text-gray-700">
                        Closed
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="text-right">
            <span class="text-2xl font-bold text-green-600">₱<?php echo e(number_format($jobPost->rate, 2)); ?></span>
            <p class="text-lg text-gray-600"><?php echo e($jobPost->location); ?></p>
        </div>
    </div>

    <div class="border-t border-gray-200 pt-6">
        <h2 class="text-xl font-semibold mb-4">Job Description</h2>
        <div class="prose max-w-none text-gray-700">
            <?php echo nl2br(e($jobPost->description)); ?>

        </div>
    </div>

    <div class="mt-8 flex flex-wrap items-center gap-3 border-t border-gray-200 pt-6">
        <a href="<?php echo e(route('job-posts.index')); ?>" class="text-gray-600 hover:underline">&larr; Back to Jobs</a>

        
        <?php if($jobPost->isAcceptableBy(Auth::user())): ?>
            <form action="<?php echo e(route('job-posts.accept', $jobPost)); ?>" method="POST"
                  onsubmit="return confirm('Accept this job? It will be added to your contracts.')">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Accept Job
                </button>
            </form>
        <?php endif; ?>

        
        <?php if($jobPost->isAccepted() && ($jobPost->isAcceptedBy(Auth::user()) || $jobPost->isPostedBy(Auth::user()))): ?>
            <form action="<?php echo e(route('job-posts.release', $jobPost)); ?>" method="POST"
                  onsubmit="return confirm('Cancel this contract? The job will be open again.')">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded">
                    Cancel Contract
                </button>
            </form>
        <?php endif; ?>

        <?php if($jobPost->isPostedBy(Auth::user())): ?>
            <form action="<?php echo e(route('job-posts.toggle-status', $jobPost)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    <?php echo e($jobPost->isOpen() ? 'Close Job' : 'Reopen Job'); ?>

                </button>
            </form>

            <a href="<?php echo e(route('job-posts.edit', $jobPost)); ?>" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                Update Post
            </a>

            <form action="<?php echo e(route('job-posts.destroy', $jobPost)); ?>" method="POST"
                  onsubmit="return confirm('Delete this job post permanently?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                    Delete Post
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Russel Carillo\OneDrive\Documents\labor_finder - Copy\app\resources\views/jobs/show.blade.php ENDPATH**/ ?>